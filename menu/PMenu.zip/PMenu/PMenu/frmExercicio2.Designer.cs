﻿namespace PMenu
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btncomparar = new System.Windows.Forms.Button();
            this.btninserie1 = new System.Windows.Forms.Button();
            this.btninserie2 = new System.Windows.Forms.Button();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btncomparar
            // 
            this.btncomparar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btncomparar.Location = new System.Drawing.Point(80, 147);
            this.btncomparar.Name = "btncomparar";
            this.btncomparar.Size = new System.Drawing.Size(114, 81);
            this.btncomparar.TabIndex = 0;
            this.btncomparar.Text = "Verifica se são iguais";
            this.btncomparar.UseVisualStyleBackColor = false;
            this.btncomparar.Click += new System.EventHandler(this.Btncomparar_Click);
            // 
            // btninserie1
            // 
            this.btninserie1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btninserie1.Location = new System.Drawing.Point(235, 147);
            this.btninserie1.Name = "btninserie1";
            this.btninserie1.Size = new System.Drawing.Size(114, 81);
            this.btninserie1.TabIndex = 1;
            this.btninserie1.Text = "Insere 1º no meio do segundo";
            this.btninserie1.UseVisualStyleBackColor = false;
            this.btninserie1.Click += new System.EventHandler(this.Btnserie1_Click);
            // 
            // btninserie2
            // 
            this.btninserie2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btninserie2.Location = new System.Drawing.Point(393, 147);
            this.btninserie2.Name = "btninserie2";
            this.btninserie2.Size = new System.Drawing.Size(114, 81);
            this.btninserie2.TabIndex = 2;
            this.btninserie2.Text = "Insere ** no meio do 1º";
            this.btninserie2.UseVisualStyleBackColor = false;
            this.btninserie2.Click += new System.EventHandler(this.Btnserie2_Click);
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(201, 52);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(264, 20);
            this.txtpalavra1.TabIndex = 3;
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(201, 91);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(264, 20);
            this.txtpalavra2.TabIndex = 4;
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(144, 52);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra1.TabIndex = 5;
            this.lblpalavra1.Text = "Palavra 1";
            this.lblpalavra1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(144, 91);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra2.TabIndex = 6;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.btninserie2);
            this.Controls.Add(this.btninserie1);
            this.Controls.Add(this.btncomparar);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btncomparar;
        private System.Windows.Forms.Button btninserie1;
        private System.Windows.Forms.Button btninserie2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
    }
}