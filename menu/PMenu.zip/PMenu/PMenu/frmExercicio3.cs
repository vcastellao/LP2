﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void FrmExercicio3_Load(object sender, EventArgs e)
        {

        }

        private void Btnremove1_Click(object sender, EventArgs e)
        {
            int posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);

            while (posicao>=0)
            {
                txtpalavra2.Text = txtpalavra2.Text.Substring(0, posicao) +
                    txtpalavra2.Text.Substring(txtpalavra1.Text.Length + posicao,
                    txtpalavra2.Text.Length - posicao - txtpalavra1.Text.Length);

                posicao = txtpalavra2.Text.IndexOf(txtpalavra1.Text);
            }
        }

        private void Btnremove2_Click(object sender, EventArgs e)
        {
            txtpalavra2.Text = txtpalavra2.Text.Replace(txtpalavra1.Text,"");
        }

        private void Btninverte_Click(object sender, EventArgs e)
        {
            // passar string para array
            char[] meuarray = txtpalavra1.Text.ToArray();
            // inverter o array usando reverse
            Array.Reverse(meuarray);

            // Voltar para string
            foreach (var c in meuarray)
                txtpalavra2.Text += c;
            // Imprimir
            MessageBox.Show(txtpalavra2.Text);
        }
    }
}
