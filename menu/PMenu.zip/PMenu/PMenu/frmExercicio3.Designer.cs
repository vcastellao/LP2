﻿namespace PMenu
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.txtpalavra2 = new System.Windows.Forms.TextBox();
            this.txtpalavra1 = new System.Windows.Forms.TextBox();
            this.btninverte = new System.Windows.Forms.Button();
            this.btnremove2 = new System.Windows.Forms.Button();
            this.btnremove1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(156, 130);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra2.TabIndex = 13;
            this.lblpalavra2.Text = "Palavra 2";
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(156, 91);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(52, 13);
            this.lblpalavra1.TabIndex = 12;
            this.lblpalavra1.Text = "Palavra 1";
            // 
            // txtpalavra2
            // 
            this.txtpalavra2.Location = new System.Drawing.Point(213, 130);
            this.txtpalavra2.Name = "txtpalavra2";
            this.txtpalavra2.Size = new System.Drawing.Size(264, 20);
            this.txtpalavra2.TabIndex = 11;
            // 
            // txtpalavra1
            // 
            this.txtpalavra1.Location = new System.Drawing.Point(213, 91);
            this.txtpalavra1.Name = "txtpalavra1";
            this.txtpalavra1.Size = new System.Drawing.Size(264, 20);
            this.txtpalavra1.TabIndex = 10;
            // 
            // btninverte
            // 
            this.btninverte.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btninverte.Location = new System.Drawing.Point(405, 186);
            this.btninverte.Name = "btninverte";
            this.btninverte.Size = new System.Drawing.Size(114, 81);
            this.btninverte.TabIndex = 9;
            this.btninverte.Text = "Inverte palavra 1";
            this.btninverte.UseVisualStyleBackColor = false;
            this.btninverte.Click += new System.EventHandler(this.Btninverte_Click);
            // 
            // btnremove2
            // 
            this.btnremove2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnremove2.Location = new System.Drawing.Point(247, 186);
            this.btnremove2.Name = "btnremove2";
            this.btnremove2.Size = new System.Drawing.Size(114, 81);
            this.btnremove2.TabIndex = 8;
            this.btnremove2.Text = "Remove ocorrências 1º no 2º (replace)";
            this.btnremove2.UseVisualStyleBackColor = false;
            this.btnremove2.Click += new System.EventHandler(this.Btnremove2_Click);
            // 
            // btnremove1
            // 
            this.btnremove1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnremove1.Location = new System.Drawing.Point(92, 186);
            this.btnremove1.Name = "btnremove1";
            this.btnremove1.Size = new System.Drawing.Size(114, 81);
            this.btnremove1.TabIndex = 7;
            this.btnremove1.Text = "Remove ocorrências 1º no 2º";
            this.btnremove1.UseVisualStyleBackColor = false;
            this.btnremove1.Click += new System.EventHandler(this.Btnremove1_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Controls.Add(this.txtpalavra2);
            this.Controls.Add(this.txtpalavra1);
            this.Controls.Add(this.btninverte);
            this.Controls.Add(this.btnremove2);
            this.Controls.Add(this.btnremove1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.Load += new System.EventHandler(this.FrmExercicio3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.TextBox txtpalavra2;
        private System.Windows.Forms.TextBox txtpalavra1;
        private System.Windows.Forms.Button btninverte;
        private System.Windows.Forms.Button btnremove2;
        private System.Windows.Forms.Button btnremove1;
    }
}