﻿namespace PClasses1
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatr = new System.Windows.Forms.Label();
            this.txtbMat = new System.Windows.Forms.TextBox();
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.btnInst = new System.Windows.Forms.Button();
            this.rdbSim = new System.Windows.Forms.RadioButton();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSal = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.txtbNome = new System.Windows.Forms.TextBox();
            this.txtbSal = new System.Windows.Forms.TextBox();
            this.txtbData = new System.Windows.Forms.TextBox();
            this.rdbNao = new System.Windows.Forms.RadioButton();
            this.btnInstPar = new System.Windows.Forms.Button();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMatr
            // 
            this.lblMatr.AutoSize = true;
            this.lblMatr.Location = new System.Drawing.Point(111, 34);
            this.lblMatr.Name = "lblMatr";
            this.lblMatr.Size = new System.Drawing.Size(50, 13);
            this.lblMatr.TabIndex = 0;
            this.lblMatr.Text = "Matricula";
            this.lblMatr.Click += new System.EventHandler(this.LblMatr_Click);
            // 
            // txtbMat
            // 
            this.txtbMat.Location = new System.Drawing.Point(167, 31);
            this.txtbMat.Name = "txtbMat";
            this.txtbMat.Size = new System.Drawing.Size(100, 20);
            this.txtbMat.TabIndex = 1;
            this.txtbMat.TextChanged += new System.EventHandler(this.TxtbMat_TextChanged);
            // 
            // gbxHome
            // 
            this.gbxHome.Controls.Add(this.rdbNao);
            this.gbxHome.Controls.Add(this.rdbSim);
            this.gbxHome.Location = new System.Drawing.Point(282, 31);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Size = new System.Drawing.Size(153, 100);
            this.gbxHome.TabIndex = 2;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalha em Home Office?";
            this.gbxHome.Enter += new System.EventHandler(this.GbxHome_Enter);
            // 
            // btnInst
            // 
            this.btnInst.Location = new System.Drawing.Point(88, 178);
            this.btnInst.Name = "btnInst";
            this.btnInst.Size = new System.Drawing.Size(125, 39);
            this.btnInst.TabIndex = 3;
            this.btnInst.Text = "Instanciar Mensalista";
            this.btnInst.UseVisualStyleBackColor = true;
            this.btnInst.Click += new System.EventHandler(this.BtnInst_Click);
            // 
            // rdbSim
            // 
            this.rdbSim.AutoSize = true;
            this.rdbSim.Location = new System.Drawing.Point(6, 26);
            this.rdbSim.Name = "rdbSim";
            this.rdbSim.Size = new System.Drawing.Size(42, 17);
            this.rdbSim.TabIndex = 4;
            this.rdbSim.TabStop = true;
            this.rdbSim.Text = "Sim";
            this.rdbSim.UseVisualStyleBackColor = true;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(126, 57);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            this.lblNome.Click += new System.EventHandler(this.LblNome_Click);
            // 
            // lblSal
            // 
            this.lblSal.AutoSize = true;
            this.lblSal.Location = new System.Drawing.Point(85, 85);
            this.lblSal.Name = "lblSal";
            this.lblSal.Size = new System.Drawing.Size(76, 13);
            this.lblSal.TabIndex = 6;
            this.lblSal.Text = "Salário Mensal";
            this.lblSal.Click += new System.EventHandler(this.LblSal_Click);
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(17, 111);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(144, 13);
            this.lblData.TabIndex = 7;
            this.lblData.Text = "Data de Entrada na Empresa";
            this.lblData.Click += new System.EventHandler(this.LblData_Click);
            // 
            // txtbNome
            // 
            this.txtbNome.Location = new System.Drawing.Point(167, 54);
            this.txtbNome.Name = "txtbNome";
            this.txtbNome.Size = new System.Drawing.Size(100, 20);
            this.txtbNome.TabIndex = 8;
            this.txtbNome.TextChanged += new System.EventHandler(this.TxtbNome_TextChanged);
            // 
            // txtbSal
            // 
            this.txtbSal.Location = new System.Drawing.Point(167, 82);
            this.txtbSal.Name = "txtbSal";
            this.txtbSal.Size = new System.Drawing.Size(100, 20);
            this.txtbSal.TabIndex = 9;
            this.txtbSal.TextChanged += new System.EventHandler(this.TxtbSal_TextChanged);
            // 
            // txtbData
            // 
            this.txtbData.Location = new System.Drawing.Point(167, 108);
            this.txtbData.Name = "txtbData";
            this.txtbData.Size = new System.Drawing.Size(100, 20);
            this.txtbData.TabIndex = 10;
            this.txtbData.TextChanged += new System.EventHandler(this.TxtbData_TextChanged);
            // 
            // rdbNao
            // 
            this.rdbNao.AutoSize = true;
            this.rdbNao.Location = new System.Drawing.Point(6, 54);
            this.rdbNao.Name = "rdbNao";
            this.rdbNao.Size = new System.Drawing.Size(45, 17);
            this.rdbNao.TabIndex = 11;
            this.rdbNao.TabStop = true;
            this.rdbNao.Text = "Não";
            this.rdbNao.UseVisualStyleBackColor = true;
            // 
            // btnInstPar
            // 
            this.btnInstPar.Location = new System.Drawing.Point(241, 178);
            this.btnInstPar.Name = "btnInstPar";
            this.btnInstPar.Size = new System.Drawing.Size(125, 39);
            this.btnInstPar.TabIndex = 11;
            this.btnInstPar.Text = "Instanciar Mensalista Passadno Parametros";
            this.btnInstPar.UseVisualStyleBackColor = true;
            this.btnInstPar.Click += new System.EventHandler(this.BtnInstPar_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(479, 281);
            this.Controls.Add(this.btnInstPar);
            this.Controls.Add(this.txtbData);
            this.Controls.Add(this.txtbSal);
            this.Controls.Add(this.txtbNome);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblSal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnInst);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.txtbMat);
            this.Controls.Add(this.lblMatr);
            this.Name = "frmMensalista";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.FrmMensalista_Load);
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatr;
        private System.Windows.Forms.TextBox txtbMat;
        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.Button btnInst;
        private System.Windows.Forms.RadioButton rdbSim;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSal;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox txtbNome;
        private System.Windows.Forms.TextBox txtbSal;
        private System.Windows.Forms.TextBox txtbData;
        private System.Windows.Forms.RadioButton rdbNao;
        private System.Windows.Forms.Button btnInstPar;
    }
}