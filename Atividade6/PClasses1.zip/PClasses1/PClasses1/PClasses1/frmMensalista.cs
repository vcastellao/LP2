﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses1
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void FrmMensalista_Load(object sender, EventArgs e)
        {
          
        }

        private void BtnInstPar_Click(object sender, EventArgs e)
        {

        }

        private void TxtbData_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtbSal_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtbNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void LblData_Click(object sender, EventArgs e)
        {

        }

        private void LblSal_Click(object sender, EventArgs e)
        {

        }

        private void LblNome_Click(object sender, EventArgs e)
        {

        }

        private void BtnInst_Click(object sender, EventArgs e)
        {
            //set
            Mensalista objMensalista = new Mensalista();
            objMensalista.Matricula = Convert.ToInt32(txtbMat.Text);
            objMensalista.NomeEmpregado = txtbNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(txtbData.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(txtbSal.Text);

            if (rdbSim.Checked)
                objMensalista.HomeOffice = 'S';
            else
                objMensalista.HomeOffice = 'N';

            //get


            MessageBox.Show("Matrícula: " + objMensalista.Matricula + "\n" +
                "Nome Empregado: " + objMensalista.NomeEmpregado + "\n" +
                "Data de Entrada na Empresa:" + objMensalista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                "Salario Bruto:" + objMensalista.SalarioBruto().ToString("N2") + "\n" +
                "Tempo Empresa (dias):" + objMensalista.TempoTrabalho() + "\n" 
                + objMensalista.VerificaHome());
        }

        private void GbxHome_Enter(object sender, EventArgs e)
        {

        }

        private void TxtbMat_TextChanged(object sender, EventArgs e)
        {

        }

        private void LblMatr_Click(object sender, EventArgs e)
        {

        }
    }
}
