﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses1
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void LblNumHor_Click(object sender, EventArgs e)
        {

        }

        private void BtnInst_Click(object sender, EventArgs e)
        {
            //set
            Horista objHorista = new Horista();
            objHorista.Matricula = Convert.ToInt32(txtbMat.Text);
            objHorista.NomeEmpregado = txtbNome.Text;
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtbData.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtbNumHor.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtbSal.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtbFalt.Text);

            if (rdbSim.Checked)
                objHorista.HomeOffice = 'S';
            else
                objHorista.HomeOffice = 'N';

            //get


            MessageBox.Show("Matrícula: " + objHorista.Matricula + "\n" +
                "Nome Empregado: " + objHorista.NomeEmpregado + "\n" +
                "Data de Entrada na Empresa:" + objHorista.DataEntradaEmpresa.ToShortDateString() + "\n" +
                "Numero Horas:" + objHorista.NumeroHora.ToString() + "\n" +
                "Salario Horas:" + objHorista.SalarioHora.ToString() + "\n" +
                "Salario Bruto:" + objHorista.SalarioBruto().ToString("N2") + "\n" +
                "Dias Falta" + objHorista.DiasFalta.ToString() + "\n" +
                "Tempo Empresa (dias):" + objHorista.TempoTrabalho() + "\n" 
                + objHorista.VerificaHome());
        }
    }
}
