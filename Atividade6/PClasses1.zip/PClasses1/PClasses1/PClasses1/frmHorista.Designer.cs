﻿namespace PClasses1
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstPar = new System.Windows.Forms.Button();
            this.txtbData = new System.Windows.Forms.TextBox();
            this.txtbSal = new System.Windows.Forms.TextBox();
            this.txtbNome = new System.Windows.Forms.TextBox();
            this.lblData = new System.Windows.Forms.Label();
            this.lblSalHor = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.btnInst = new System.Windows.Forms.Button();
            this.gbxHome = new System.Windows.Forms.GroupBox();
            this.rdbNao = new System.Windows.Forms.RadioButton();
            this.rdbSim = new System.Windows.Forms.RadioButton();
            this.txtbMat = new System.Windows.Forms.TextBox();
            this.lblMatr = new System.Windows.Forms.Label();
            this.lblNumHor = new System.Windows.Forms.Label();
            this.txtbNumHor = new System.Windows.Forms.TextBox();
            this.lblFalt = new System.Windows.Forms.Label();
            this.txtbFalt = new System.Windows.Forms.TextBox();
            this.gbxHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnInstPar
            // 
            this.btnInstPar.Location = new System.Drawing.Point(235, 191);
            this.btnInstPar.Name = "btnInstPar";
            this.btnInstPar.Size = new System.Drawing.Size(125, 39);
            this.btnInstPar.TabIndex = 22;
            this.btnInstPar.Text = "Instanciar Horista Passadno Parametros";
            this.btnInstPar.UseVisualStyleBackColor = true;
            // 
            // txtbData
            // 
            this.txtbData.Location = new System.Drawing.Point(167, 89);
            this.txtbData.Name = "txtbData";
            this.txtbData.Size = new System.Drawing.Size(100, 20);
            this.txtbData.TabIndex = 21;
            // 
            // txtbSal
            // 
            this.txtbSal.Location = new System.Drawing.Point(167, 63);
            this.txtbSal.Name = "txtbSal";
            this.txtbSal.Size = new System.Drawing.Size(100, 20);
            this.txtbSal.TabIndex = 20;
            // 
            // txtbNome
            // 
            this.txtbNome.Location = new System.Drawing.Point(167, 35);
            this.txtbNome.Name = "txtbNome";
            this.txtbNome.Size = new System.Drawing.Size(100, 20);
            this.txtbNome.TabIndex = 19;
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Location = new System.Drawing.Point(17, 92);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(144, 13);
            this.lblData.TabIndex = 18;
            this.lblData.Text = "Data de Entrada na Empresa";
            // 
            // lblSalHor
            // 
            this.lblSalHor.AutoSize = true;
            this.lblSalHor.Location = new System.Drawing.Point(85, 66);
            this.lblSalHor.Name = "lblSalHor";
            this.lblSalHor.Size = new System.Drawing.Size(65, 13);
            this.lblSalHor.TabIndex = 17;
            this.lblSalHor.Text = "Salário Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(126, 38);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 16;
            this.lblNome.Text = "Nome";
            // 
            // btnInst
            // 
            this.btnInst.Location = new System.Drawing.Point(88, 191);
            this.btnInst.Name = "btnInst";
            this.btnInst.Size = new System.Drawing.Size(125, 39);
            this.btnInst.TabIndex = 15;
            this.btnInst.Text = "Instanciar Horista";
            this.btnInst.UseVisualStyleBackColor = true;
            this.btnInst.Click += new System.EventHandler(this.BtnInst_Click);
            // 
            // gbxHome
            // 
            this.gbxHome.Controls.Add(this.rdbNao);
            this.gbxHome.Controls.Add(this.rdbSim);
            this.gbxHome.Location = new System.Drawing.Point(282, 12);
            this.gbxHome.Name = "gbxHome";
            this.gbxHome.Size = new System.Drawing.Size(153, 100);
            this.gbxHome.TabIndex = 14;
            this.gbxHome.TabStop = false;
            this.gbxHome.Text = "Trabalha em Home Office?";
            // 
            // rdbNao
            // 
            this.rdbNao.AutoSize = true;
            this.rdbNao.Location = new System.Drawing.Point(6, 54);
            this.rdbNao.Name = "rdbNao";
            this.rdbNao.Size = new System.Drawing.Size(45, 17);
            this.rdbNao.TabIndex = 11;
            this.rdbNao.TabStop = true;
            this.rdbNao.Text = "Não";
            this.rdbNao.UseVisualStyleBackColor = true;
            // 
            // rdbSim
            // 
            this.rdbSim.AutoSize = true;
            this.rdbSim.Location = new System.Drawing.Point(6, 26);
            this.rdbSim.Name = "rdbSim";
            this.rdbSim.Size = new System.Drawing.Size(42, 17);
            this.rdbSim.TabIndex = 4;
            this.rdbSim.TabStop = true;
            this.rdbSim.Text = "Sim";
            this.rdbSim.UseVisualStyleBackColor = true;
            // 
            // txtbMat
            // 
            this.txtbMat.Location = new System.Drawing.Point(167, 12);
            this.txtbMat.Name = "txtbMat";
            this.txtbMat.Size = new System.Drawing.Size(100, 20);
            this.txtbMat.TabIndex = 13;
            // 
            // lblMatr
            // 
            this.lblMatr.AutoSize = true;
            this.lblMatr.Location = new System.Drawing.Point(111, 15);
            this.lblMatr.Name = "lblMatr";
            this.lblMatr.Size = new System.Drawing.Size(50, 13);
            this.lblMatr.TabIndex = 12;
            this.lblMatr.Text = "Matricula";
            // 
            // lblNumHor
            // 
            this.lblNumHor.AutoSize = true;
            this.lblNumHor.Location = new System.Drawing.Point(86, 120);
            this.lblNumHor.Name = "lblNumHor";
            this.lblNumHor.Size = new System.Drawing.Size(75, 13);
            this.lblNumHor.TabIndex = 23;
            this.lblNumHor.Text = "Numero Horas";
            this.lblNumHor.Click += new System.EventHandler(this.LblNumHor_Click);
            // 
            // txtbNumHor
            // 
            this.txtbNumHor.Location = new System.Drawing.Point(167, 117);
            this.txtbNumHor.Name = "txtbNumHor";
            this.txtbNumHor.Size = new System.Drawing.Size(100, 20);
            this.txtbNumHor.TabIndex = 24;
            // 
            // lblFalt
            // 
            this.lblFalt.AutoSize = true;
            this.lblFalt.Location = new System.Drawing.Point(107, 149);
            this.lblFalt.Name = "lblFalt";
            this.lblFalt.Size = new System.Drawing.Size(54, 13);
            this.lblFalt.TabIndex = 25;
            this.lblFalt.Text = "Dias Falta";
            // 
            // txtbFalt
            // 
            this.txtbFalt.Location = new System.Drawing.Point(167, 146);
            this.txtbFalt.Name = "txtbFalt";
            this.txtbFalt.Size = new System.Drawing.Size(100, 20);
            this.txtbFalt.TabIndex = 26;
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(495, 293);
            this.Controls.Add(this.txtbFalt);
            this.Controls.Add(this.lblFalt);
            this.Controls.Add(this.txtbNumHor);
            this.Controls.Add(this.lblNumHor);
            this.Controls.Add(this.btnInstPar);
            this.Controls.Add(this.txtbData);
            this.Controls.Add(this.txtbSal);
            this.Controls.Add(this.txtbNome);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblSalHor);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnInst);
            this.Controls.Add(this.gbxHome);
            this.Controls.Add(this.txtbMat);
            this.Controls.Add(this.lblMatr);
            this.Name = "frmHorista";
            this.Text = "Form2";
            this.gbxHome.ResumeLayout(false);
            this.gbxHome.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInstPar;
        private System.Windows.Forms.TextBox txtbData;
        private System.Windows.Forms.TextBox txtbSal;
        private System.Windows.Forms.TextBox txtbNome;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Label lblSalHor;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Button btnInst;
        private System.Windows.Forms.GroupBox gbxHome;
        private System.Windows.Forms.RadioButton rdbNao;
        private System.Windows.Forms.RadioButton rdbSim;
        private System.Windows.Forms.TextBox txtbMat;
        private System.Windows.Forms.Label lblMatr;
        private System.Windows.Forms.Label lblNumHor;
        private System.Windows.Forms.TextBox txtbNumHor;
        private System.Windows.Forms.Label lblFalt;
        private System.Windows.Forms.TextBox txtbFalt;
    }
}