﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace ProvaLP
{
    public partial class Form1 : Form
    {
        public int[,] MJogadores;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MJogadores = new int[3, 3];
        }

        private void BtnExe_Click(object sender, EventArgs e)
        {
            float media, mediaG = 0;
            for (int i = 0; i < 3; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    if (j == 0)
                    {
                        string input = Microsoft.VisualBasic.Interaction.InputBox("Dificuldade Facil!", $"Informe a Pontuação do Jogador {i + 1}:");
                        
                        if (!int.TryParse(input , out MJogadores[i, j]))
                        {
                            MessageBox.Show("informe um valor valido!");
                            j--;
                        }
                        else if (MJogadores[i,j] <= 0)
                        {
                            MessageBox.Show("Informe um Valor Valido!");
                            j--;
                            
                        }
                        else
                        {
                            media = media + MJogadores[i, j];
                        }

                    }
                    else if (j == 1)
                    {
                        string input = Microsoft.VisualBasic.Interaction.InputBox("Dificuldade Media!", $"Informe a Pontuação do Jogador {i + 1}:");
                        if (!int.TryParse(input, out MJogadores[i, j]))
                        {
                            MessageBox.Show("informe um valor valido!");
                            j--;
                        }
                        else if (MJogadores[i, j] <= 0)
                        {
                            MessageBox.Show("Informe um Valor Valido!");
                            j--;

                        }
                        else
                        {
                            media = media + MJogadores[i, j];
                        }
                    }
                    else
                    {
                        string input = Microsoft.VisualBasic.Interaction.InputBox("Dificuldade Dificil!", $"Informe a Pontuação do Jogador {i + 1}:");
                        if (!int.TryParse(input, out MJogadores[i, j]))
                        {
                            MessageBox.Show("informe um valor valido!");
                            j--;
                        }
                        else if (MJogadores[i, j] <= 0)
                        {
                            MessageBox.Show("Informe um Valor Valido!");
                            j--;

                        }
                        else
                        {
                            media = media + MJogadores[i, j];
                        }
                    }
                    }
                media = media / 3;
                mediaG = media + mediaG;
                lbox.Items.Add($"Jogador {i + 1} Pontos Nivel Facil: {MJogadores[i, 0]}, Nivel Medio: {MJogadores[i, 1]}, Nivel Dificil: {MJogadores[i, 2]}, Media: {media.ToString("F2")}");
                }
            mediaG = mediaG / 3;
            lbox.Items.Add($"A Media Geral dos jogadores é de: {mediaG.ToString("F2")}");
            }


        private void Lbox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
        }